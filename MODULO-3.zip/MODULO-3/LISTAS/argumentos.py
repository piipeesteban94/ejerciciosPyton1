import sys 

nombre = sys.argv[1]
edad = int(sys.argv[2]) # STRING -> int

print(f'Soy {nombre} y tengo {edad} años')

# Es tipo de input()