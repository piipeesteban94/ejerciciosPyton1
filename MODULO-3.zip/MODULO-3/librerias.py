import math 

# math.ceil

print(math.ceil(3.14)) # -> 4 <- redondea hacia arriba

"""
En caso de no tener dicha librería, ejecutamos:
pip install math

pip install pandas
"""

# Importar solo un método (función de dicha librería)
# from math import ceil
# print(ceil(3.14))