
#     0 1  2  3  4 <- indexada
# list [1,1,22,31,43,43,15] <- FOR
# set {1,22,31,43,15} <- list
# dict diccionario {"key": "value"} <- .items() FOR
# tuple () <- list

# STRING