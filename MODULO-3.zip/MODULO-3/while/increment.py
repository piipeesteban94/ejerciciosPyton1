i = 0 
while i < 10: # en la condición introducimos el CASO CORTE
    # i = i + 1
    print(i)
    i += 1 # CASO CORTE
    # print(i)

#* secuencia de pasos FINITA
# condición de salida o término del ciclo
    