
#TODO: Concatenar

nombre = "Jimy"
apellido = "Hendrix"

print(nombre + apellido)

saludo = "Hola"

saludo += " Mundo!!!" # saludo = saludo + " Mundo!!!"
#                                "Hola"
saludo += " esta todo OK"
print(saludo) # Hola Mundo!!! esta todo OK