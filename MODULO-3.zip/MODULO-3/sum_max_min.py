

lista_num = [3,4,77,10] 

set_num = {32,1,12,6}

tupla_num = (2,3,4)

print(sum(lista_num))  # 94

print(max(tupla_num)) # 4

print(min(set_num)) # 1



#TODO: ENCUESTA https://forms.gle/avKKrqnBXbKdRSVs8 2 min