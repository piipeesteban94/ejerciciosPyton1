

# TODO: BREACK

# * LIST
perros = ["doberman", "dogman", "boby"]
buscar = input("Ingrese perro: ")

for perro in perros:
    print(perro)
    if buscar == "doberman":
        break # Cuando este se ejecuta el CICLO se termina

print("Fin del CODE")

# * STRING

texto = "mau@hotmail.com"
arroba = False
for t in texto:
    print(f'--> {t}')
    if t == "@":
        arroba = True
        break # Cuando este se ejecuta el CICLO se termina
    
if arroba:
    print("Tiene formato de email")
else:
    print("NO tiene formato de email")